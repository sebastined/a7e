#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//Number 3

void textManager(unsigned char inputArray[200]) {
    int length;
    char temp;

    // Get length from user
    printf("Enter the length of text you want to input: ");
    scanf("%d", &length);
    getchar(); // clear input buffer

    // Get string from user
    printf("Enter your text: ");
    fgets((char*)inputArray, 200, stdin);

    // Remove newline character if present
    if (inputArray[strlen((char*)inputArray) - 1] == '\n') {
        inputArray[strlen((char*)inputArray) - 1] = '\0';
    }

    if (length < 5) {
        // Reverse the string
        int i;
        int str_len = strlen((char*)inputArray);
        for (i = 0; i < str_len/2; i++) {
            temp = inputArray[i];
            inputArray[i] = inputArray[str_len - 1 - i];
            inputArray[str_len - 1 - i] = temp;
        }
        printf("Reversed string: %s\n", inputArray);
        printf("Length: %d\n", length);
    } else {
        // Remove 'a' and 'b' characters
        int i, j;
        int str_len = strlen((char*)inputArray);
        for(i = 0, j = 0; i < str_len; i++) {
            if(inputArray[i] != 'a' && inputArray[i] != 'b') {
                inputArray[j] = inputArray[i];
                j++;
            }
        }
        inputArray[j] = '\0'; // Terminate the modified string

        printf("Modified string (a and b removed): %s\n", inputArray);
        printf("Length: %d\n", length);
    }
}

int main(int argc, char *argv[]) {    // Proper main declaration for Windows
    unsigned char inputArray[200];
    textManager(inputArray);

    system("pause");    // This will keep the console window open
    return 0;
}
