#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {
void number_to_screen(void) {
    for (int i = 101; i >= 1; i--) {
        if (i != 7 && i != 17 && i != 27 && i != 77) {
            printf("%d\t", i);
        }
    }
}

 {
    number_to_screen();
    
}



//Number 4

printf("\n");

int a[3][3];
int i,j,m,n;

// printf("Enter the order of the matrix : ");
// scanf("%d %d",&m,&n);
printf("Enter the row of the matrix :\n ");
scanf("%d",&m);
printf("Enter the column matrix :\n ");
scanf("%d",&n);
printf("Enter the elements of the matrix :\n ");
for (i = 0; i < m; i++)
for (j = 0; j < n; j++)
scanf("%d", &a[i][j]);
printf("The matrix is : \n");
for (i = 0; i < m; i++)
{
for (j = 0; j < n; j++)
printf("%d ", a[i][j]);
printf("\n");


}

return 0;
}


